
const express = require('express')
const app = express()
const User = require('./Models/users')
const bcrypt = require('bcrypt')
const format = require('date-fns')
const ExpressBrute = require('express-brute')
//var ExpressBrute = require('express-brute')
var store = new ExpressBrute.MemoryStore(); // stores state locally, don't use this in production
var bruteforce = new ExpressBrute(store);
const helmet = require('helmet')

const cors = require('cors')
const mongodb = require('mongodb')
const jwt = require('jsonwebtoken')
const isAuthenticated = require('./Models/auth')
const Issues = require('./Models/issues')
const connstring = 'mongodb+srv://st10090375:5hNT6bmtcRAQEhHO@cluster0.2wjrrvl.mongodb.net/'
const mongoose = require('mongoose')

const corsOpt = {
    origin: 'http://localhost:4200',
    methods: 'GET,HEAD,PUT,PATCH,POST,DELETE',
    credentials: true,
    allowedHeaders: ['Content-Type', 'Authorization']
}

app.use(express.json());
app.use(helmet());
app.use(cors(corsOpt))

mongoose.connect(connstring, {useNewUrlParser: true, useUnifiedTopology: true})
.then(client =>{
    //trying to use a database with mongodb
    console.log('Connection established successfully')
})
.catch(error =>{
    console.error('Connection to MongoDB has failed')
})




//Create a secure account 
const saltRound = 10 
app.post('/register', (req, res) =>{
    console.log("Register called")
    bcrypt.hash(req.body.password, saltRound)
    .then(hash => {
        const user = new User({
            firstName: req.body.firstName,
            Surname: req.body.Surname,
            email: req.body.email,
            username: req.body.username,
            password: hash
        })
        user.save()
        .then(result => {
            res.status(201).json({message: 'User created successfully', result: result})
            console.log("User created")
        })
        .catch(error => {
            console.log("User not created")
            console.error(error.message)
            res.status(500).json({error: 'Failed'})
        })
    })
    .catch(err => {
        res.status(500).json({error: 'Failed to hash'})
    })
})


app.post('/login',bruteforce.prevent,(req, res)=> {
    const {username, password } = req.body
    User.findOne({username})
    .then(user => {
        if(!user){
            return res.status(401).json({error: 'User does not exist'})
        }
        bcrypt.compare(password, user.password)
        .then(match => {
            if(match){
                const token = jwt.sign({username: user.username, userID: user._id},
                    'MyWebTokenStringToSecureMyToken',{expiresIn: '1h'})
                
                res.status(200).json({message: 'Welcome ' + username,
                 token: token})
                                       
                
            }else{
                res.status(401).json({error: 'Authentication failed'})
            }
        })
        .catch(err =>{
            res.status(500).json({error: 'Please check password or username'})
        })
    })
    .catch(err => {
        res.status(500).json({error: 'User does not exist'})
    })
})
//Creating a new issue  
app.post('/issues',cors(),isAuthenticated, async (req, res) =>{

    const newIssue = req.body
    try{
        const newIssueData = await Issues.create(newIssue)
        res.status(201).json(newIssueData)
        consol.log("Issue Added")
       // res.json(newIssueData)
    }catch(error)
{
    res.status(500).json({error: 'error occured'})
}}
)
//Reading from mongodb
app.get('/getIssues',cors(), isAuthenticated, (req, res)=>{
    Issues.find()
    .then((newIssue) =>{
        res.json({
            message: 'User Issues found',
            newIssue: newIssue
        })
    })
})

//Deleting the issue
app.delete('/issues/:id',cors(), isAuthenticated, (req, res) =>{
    Issues.deleteOne({_id: req.params.id})
    .then((result) =>{
        res.status(200).json({message: 'Issue removed successfully'})
    })
    .catch(err => {
        res.status(401).json({message: 'Failed to delete'})
    })
})
module.exports = app