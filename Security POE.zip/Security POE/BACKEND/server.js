const app = require('./index')
const port = 3000
const fs = require('fs')
const https = require('https')
const http = require('http')
const options ={
    key: fs.readFileSync('Keys/privatekey.pem'),
    cert: fs.readFileSync('Keys/certificate.pem')
}
const httpserver = http.createServer((req, res) =>{
    const httpUrl = 'https://${req.headers.host}${req.url}'
    res.writeHead(301, {Location: httpUrl})
    res.end()
})

const server = https.createServer(options, app)
httpserver.listen(80, () => {
console.log('Http started on port #... Redirecting')
})
//run on a port number 
//do everything within the curly braces 
//for this application it will run the console 
server.listen(port, ()=>{
    console.log('Server started on port ' + port)
})